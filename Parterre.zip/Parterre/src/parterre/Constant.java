/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parterre;

import java.awt.image.BufferedImage;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class Constant {
    public static final int WIDTH=10;
    public static final int HEIGHT=10;
     public static String[] flowerImage=new String[]{
         "./resource/p1.png","./resource/p2.png","./resource/p3.png","./resource/p4.png",
         "./resource/p5.png","./resource/p6.png","./resource/p7.png","./resource/p8.png"
     };//flower texture
     public static List<Parterre> parterres=new ArrayList<Parterre>();
}
