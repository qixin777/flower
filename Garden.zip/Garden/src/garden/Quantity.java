/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package garden;

import java.awt.image.BufferedImage;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class Quantity {
    public static final int WIDTH=10;
    public static final int HEIGHT=10;
     public static String[] flower_Image=new String[]{
         "./res/flower1.png","./res/flower2.png","./res/flower3.png","./res/flower4.png",
         "./res/flower5.png","./res/flower6.png","./res/flower7.png","./res/flower8.png"
     };//flower texture
     public static List<Garden> parterres=new ArrayList<Garden>();
}
